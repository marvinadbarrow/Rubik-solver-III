export default {
	root: 'src/',
	publicDir: '../public/',
	base: './',
	build:
	{
		outDir: '../dist',
		emptyOutDir: true,
		sourcemap: true
	}
}
