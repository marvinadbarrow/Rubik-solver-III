1. Install packages
-------------------------
npm i -D vite
-------------------------
npm i three
-------------------------

2. Run the development server
-------------------------
npm start
-------------------------

3. Build(create files for deployment)
-------------------------
npm run build
-------------------------
